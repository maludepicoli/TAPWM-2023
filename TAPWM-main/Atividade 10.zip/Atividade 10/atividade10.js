function verificarTriangulo() {
    const a = parseFloat(document.getElementById("a").value);
    const b = parseFloat(document.getElementById("b").value);
    const c = parseFloat(document.getElementById("c").value);

    const resultadoElement = document.getElementById("resultado");
    
    if (isNaN(a) || isNaN(b) || isNaN(c)) {
        document.getElementById("resultado").innerHTML = "Por favor, insira valores válidos.";
        return;
    }
    
    if (a > 0 && b > 0 && c > 0 && a + b > c && a + c > b && b + c > a) {
        if (a === b && b === c) {
            resultadoElement.innerText = "É um Triângulo Equilátero";
        } else if (a === b || b === c || a === c) {
            resultadoElement.innerText = "É um Triângulo Isósceles";
        } else {
            resultadoElement.innerText = "É um Triângulo Escaleno";
        }
    } else {
        resultadoElement.innerText = "Esses valores não formam um triângulo válido.";
    }
}


