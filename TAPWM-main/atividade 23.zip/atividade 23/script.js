function procura() {
    let texto = prompt("Digite um texto:");

    let textoMinusculo = texto.toLowerCase();
  
    let contador = 0;
    for (let i = 0; i < textoMinusculo.length; i++) {
      if (textoMinusculo[i] === 'a') {
        contador++;
      }
    }
  
    console.log( "Quantidade de letras 'A' encontradas: " + contador);
  }
  procura();