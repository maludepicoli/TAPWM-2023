function ordena() {
    let numeros = [];
  
    
    for (let i = 0; i < 5; i++) {
      let numero = prompt("Digite o número" );
      numeros.push(parseFloat(numero)); 
    }
    numeros.sort((a, b) => b - a);
    console.log("Números em ordem decrescente: " + numeros);
    
  }
  ordena();