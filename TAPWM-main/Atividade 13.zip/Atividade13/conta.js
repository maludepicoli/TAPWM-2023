function mostrarDados() {
    function Conta() {
        var nome_correntista;
        var banco;
        var num_conta;
        var saldo;
        this.setNomeCorrentista = function (value) {
            this.nome_correntista = value;
        }
        this.getNomeCorrentista = function () {
            return this.nome_correntista;
        }
        this.setBanco = function (value) {
            this.banco = value;
        }
        this.getBanco = function () {
            return this.banco;
        }
        this.setNumConta = function (value) {
            this.num_conta = value;
        }
        this.getNumConta = function () {
            return this.num_conta;
        }
        this.setSaldo = function (value) {
            this.saldo = value;
        }
        this.getSaldo = function () {
            return this.saldo;
        }
    }

    function Corrente() {
        Conta.call(this);
        var saldoEspecial;

        this.setSaldoEspecial = function (value) {
            saldoEspecial = value;
        }

        this.getSaldoEspecial = function () {
            return saldoEspecial;
        }
    }

    Corrente.prototype = Object.create(Conta.prototype);

    function Poupanca() {
        Conta.call(this);

        var juros, dataVencimento;

        this.setJuros = function (value) {
            juros = value;
        }

        this.getJuros = function () {
            return juros;
        }

        this.setDataVencimento = function (value) {
            dataVencimento = value;
        }

        this.getDataVencimento = function () {
            return dataVencimento;
        }
    }

    Poupanca.prototype = Object.create(Conta.prototype);

    var objContaCorrente = new Corrente();
    objContaCorrente.setNomeCorrentista('Maria');
    objContaCorrente.setBanco('Inter');
    objContaCorrente.setNumConta('000000');
    objContaCorrente.setSaldo(1000);
    objContaCorrente.setSaldoEspecial(100000);

    var objContaPoupanca = new Poupanca();
    objContaPoupanca.setNomeCorrentista('Luiza');
    objContaPoupanca.setBanco('Banco do Brasil');
    objContaPoupanca.setNumConta('000000');
    objContaPoupanca.setSaldo(2000);
    objContaPoupanca.setJuros(0.01);
    objContaPoupanca.setDataVencimento('24/10/2023');

    alert("Nome do Correntista: " +  objContaCorrente.getNomeCorrentista() + "\nBanco: " + objContaCorrente.getBanco() + "\nNúmero da Conta: " + objContaCorrente.getNumConta() + "\nSaldo: " + objContaCorrente.getSaldo() + "\nSaldo Especial: " + objContaCorrente.getSaldoEspecial());
    alert("Nome do Correntista: " + objContaPoupanca.getNomeCorrentista() + "\nBanco: " + objContaPoupanca.getBanco() + "\nNúmero da Conta: " + objContaPoupanca.getNumConta() + "\nSaldo: " + objContaPoupanca.getSaldo() + "\nTaxa de Juros: " + objContaPoupanca.getJuros() + "\nData de Vencimento: " + objContaPoupanca.getDataVencimento());
}