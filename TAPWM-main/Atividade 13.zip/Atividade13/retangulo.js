function calcularArea() {
    function Retangulo(x, y) {
        this.x = x;
        this.y = y;
        var resultado;

        this.Area = function () {
            resultado = this.x * this.y;
            return resultado;
        }
    }

    function promptApenasLetras(mensagem) {
        let entrada = '';
        while (!/^[a-zA-Z]+$/.test(entrada)) {
          entrada = prompt(mensagem);
          if (!/^[a-zA-Z]+$/.test(entrada)) {
            alert('Por favor, digite apenas letras.');
          }
        }
        return entrada;
      }
      
      var unidadeMedida = promptApenasLetras("Qual a unidade de medida do retângulo?");
      function promptApenasNumeros(mensagem) {
        let entrada = '';
        while (!/^\d+$/.test(entrada)) {
          entrada = prompt(mensagem);
          if (!/^\d+$/.test(entrada)) {
            alert('Por favor, digite apenas números.');
          }
        }
        return parseInt(entrada, 10); 
      }      
    var base = promptApenasNumeros("Informe a base do retângulo: ");
    var altura = promptApenasNumeros("Informe a altura do retângulo: ");
    calculo = new Retangulo(base, altura);
    alert("A área do retângulo é: " + calculo.Area() + unidadeMedida + "²");
}