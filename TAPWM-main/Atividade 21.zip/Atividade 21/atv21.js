function criarObjeto() {
    event.preventDefault();
    const nome = document.getElementById("nome").value;
    const dataNasc = document.getElementById("dataNasc").value;
    const matriculado = document.querySelector('input[name="matriculado"]:checked').value;
    const endereco = document.getElementById("endereco").value;
    const hoje = new Date();
    const anoAtual = hoje.getFullYear();
    const dataNascimentoFormatada = new Date(dataNasc);
    const anoNascimento = dataNascimentoFormatada.getFullYear();
    if ((anoAtual - anoNascimento >= 7 && anoAtual - anoNascimento <= 17) && matriculado === "sim") {
      alert(`${nome} - ${dataNasc} - ${endereco} - está inscrito no torneio`);
    } else {
      alert(`${nome} - ${dataNasc} - ${endereco} - NÃO está inscrito porque não atende aos requisitos.`);
    }
   }