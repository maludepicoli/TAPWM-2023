function escolhaUsuario() {
  var inputUsuario = prompt("Escolha: pedra, papel ou tesoura").toLowerCase();
  if (inputUsuario === 'pedra' || inputUsuario === 'papel' || inputUsuario === 'tesoura') {
    return inputUsuario;
  } else {
    alert("Escolha inválida. Por favor, escolha entre pedra, papel ou tesoura.");
    return escolhaUsuario();
  }
}

function escolhaComputador() {
  var escolha = ['pedra', 'papel', 'tesoura'];
  var aleatorio = Math.floor(Math.random() * 3);
  return escolha[aleatorio];
}

function vencedor(usuario, computador) {
  if (usuario === computador) {
    return 'Empate!';
  } else if (usuario === 'pedra') {
    return computador === 'tesoura' ? 'Você ganhou!' : 'Você perdeu.';
  } else if (usuario === 'papel') {
    return computador === 'pedra' ? 'Você ganhou!' : 'Você perdeu.';
  } else if (usuario === 'tesoura') {
    return computador === 'papel' ? 'Você ganhou!' : 'Você perdeu.';
  }
}

function jogar() {
  var usuario = escolhaUsuario();
  var computador = escolhaComputador();
  alert('Você escolheu: ' + usuario);
  alert('O computador escolheu: ' + computador);
  alert(vencedor(usuario, computador));
}

jogar();
