var nomeAluno = prompt("Digite o nome do aluno:");
var nota1 = parseFloat(prompt("Digite a primeira nota:"));
var nota2 = parseFloat(prompt("Digite a segunda nota:"));
var nota3 = parseFloat(prompt("Digite a terceira nota:"));
var media = parseFloat(nota1) + parseFloat(nota2) + parseFloat(nota3) / 3;


alert("A media do aluno " + nomeAluno + " é "+ media);

