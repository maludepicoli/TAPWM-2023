var somaIdade = 0;
        var maisVelho = 0;
        var maisNovo = 900;
        var pessimo = 0;
        var bomOtimo = 0;
        var homem = 0;
        var mulher = 0;

        for(var i=0; i<45; i++){
            var idade = prompt("Qual a sua idade?");
            var sexo = prompt("Qual seu sexo? \n (homem ou mulher)").toLowerCase();
            var opiniao = prompt("Qual nota você dá para o filme entre 1 e 4? Sendo: \nótimo = 4\nbom=3\nregular=2\npéssimo=1");
            somaIdade += parseInt(idade);
            if(maisVelho<idade){
                maisVelho = idade;
            }
            if(maisNovo>idade){
                maisNovo = idade;
            }
            if(opiniao == 1){
                pessimo++;
            }
            if(opiniao == 3 || opiniao == 4){
                bomOtimo++;
            }
            if(sexo == "homem"){
                homem++;
            }
            if(sexo == "mulher"){
                mulher++;
            }
        }

        var mediaIdade = somaIdade/2
        var porcentagemBomOtimo = (bomOtimo * 100)/45;

        alert("A média de idade dos entrevistados é de: " + mediaIdade + " anos\n")
        alert("O entrevistado mais velho tem " + maisVelho + " anos")
        alert("O entrevistado mais novo tem " + maisNovo + " anos")
        alert(pessimo + " pessoa(s) votaram péssimo")
        alert("A porcentagem de pessoas que votaram bom ou ótimo é de: " + porcentagemBomOtimo + "%")
        alert(homem +" Homem(s) participaram da pesquisa ")
        alert(mulher + " Mulher(es) participaram da pesquisa")